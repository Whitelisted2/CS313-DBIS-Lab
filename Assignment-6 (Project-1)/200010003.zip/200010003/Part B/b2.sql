INSERT INTO book VALUES (
    "200001", "Hunger Games", "Sci-Fi", "Suzanne Collins");
INSERT INTO book VALUES (
    "200002", "Percy Jackson", "Adventure", "Rick Riordan");
INSERT INTO book VALUES (
    "200003", "Harry Potter", "Fantasy", "JK Rowling");
INSERT INTO book VALUES (
    "200004", "Prisoners of Geography", "Non-fiction", "Tim Marshall");
INSERT INTO book VALUES (
    "200005", "Origin Story", "Non-fiction", "David Christian");
INSERT INTO book VALUES (
    "200006", "The Psychology of Persuasion", "Non-fiction", "Robert B Cialdini");
INSERT INTO book VALUES (
    "200007", "To Kill a Mockingbird", "Classic", "Harper Lee");

INSERT INTO student VALUES ("10002", "Altmash", "CSE", 2020, 5);
INSERT INTO student VALUES ("10004", "Sourabh", "CSE", 2020, 5);
INSERT INTO student VALUES ("10012", "Devdatt", "CSE", 2020, 5);
INSERT INTO student VALUES ("20003", "Aditya", "EE", 2020, 5);
INSERT INTO student VALUES ("30003", "Abhishek", "MMAE", 2020, 5);
INSERT INTO student VALUES ("11003", "Akash", "CSE", 2021, 3);
INSERT INTO student VALUES ("21003", "Anand", "EE", 2021, 3);
INSERT INTO student VALUES ("21008", "Amit", "EE", 2021, 3);
INSERT INTO student VALUES ("22003", "Harsh", "EE", 2022, 1);
INSERT INTO student VALUES ("32003", "Manjunath", "MMAE", 2022, 1);
INSERT INTO student VALUES ("22006", "Nagesh", "EE", 2022, 1);

INSERT INTO issue VALUES ("10012", "200001", "2022-09-01", "2022-09-15");
INSERT INTO issue VALUES ("11003", "200001", "2022-10-10", "2022-10-25");
INSERT INTO issue VALUES ("21003", "200003", "2022-09-01", "2022-09-15");
INSERT INTO issue VALUES ("30003", "200004", "2022-09-01", "2022-09-15");
INSERT INTO issue VALUES ("10012", "200005", "2022-09-15", "2022-09-29");
INSERT INTO issue VALUES ("32003", "200006", "2022-09-01", "2022-09-15");
INSERT INTO issue VALUES ("21008", "200006", "2022-08-01", "2022-08-15");
INSERT INTO issue VALUES ("20003", "200006", "2022-09-01", "2022-09-15");
INSERT INTO issue VALUES ("22003", "200001", "2022-08-01", "2022-08-15");
INSERT INTO issue VALUES ("10002", "200007", "2022-09-01", "2022-09-15");
INSERT INTO issue VALUES ("30003", "200007", "2022-09-16", "2022-09-30");
