-- following are used in screenshots:
book ("200008", "And Then There Were None", 
                "Detective", "Agatha Christie")
issue ("11003", "200008", "2022-10-01")

-- some sample records to enter manually (adding books)
("200009", "The Hobbit", "Fantasy", "JRR Tolkien")
("200010", "Animal Farm", "Satire", "George Orwell")

-- some sample records to enter manually (issuing books)
("22006", "200009", "2022-09-01")
("11003", "200009", "2022-08-01")
("22006", "200010", "2022-09-01")


