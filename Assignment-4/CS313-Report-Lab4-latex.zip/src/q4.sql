source DDL.sql;
SHOW TABLES;