CREATE USER 'universityDB0003'@'localhost' IDENTIFIED BY 'wifelinlooof';
SELECT user FROM mysql.user;