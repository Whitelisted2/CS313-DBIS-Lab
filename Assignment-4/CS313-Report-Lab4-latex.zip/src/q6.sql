SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name = 'department';
SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name = 'classroom';
SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name = 'course';
SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name = 'section';
SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name = 'instructor';
SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name = 'teaches';
SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name = 'student';
SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name = 'takes';
SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name = 'advisor';
SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name = 'time_slot';
SELECT table_name, column_name, data_type FROM information_schema.columns
WHERE table_name = 'prereq';