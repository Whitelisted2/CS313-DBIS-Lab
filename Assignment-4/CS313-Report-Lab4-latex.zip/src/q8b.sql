SELECT * FROM course;
INSERT INTO course VALUES('CS-333', 'Advanced Database Systems', 'Comp. Sci.', 6);
SELECT * FROM course;
SELECT * FROM prereq;
INSERT INTO prereq VALUES('CS-333', 'CS-303');
SELECT * FROM prereq;