CREATE DATABASE university;
GRANT ALL PRIVILEGES ON university.* TO 'universityDB0003'@'localhost';