CREATE USER 'lab3'@'localhost' IDENTIFIED BY 'tumajarbisaun';
CREATE DATABASE lab3;
GRANT ALL PRIVILEGES ON lab3.* TO 'lab3'@'localhost';