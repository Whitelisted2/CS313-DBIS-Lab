INSERT INTO part VALUES (10034, "Imager Chip", "#ed795b", 3.4);
INSERT INTO supplier VALUES (2143, "Aurora Tech.", "Bengaluru", "SBI");
INSERT INTO shipment VALUES (1000232, 10034, 2143, "2022-09-01", 3400, 35.4);